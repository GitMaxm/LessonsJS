const jsonString = `{
    "1408": {
      "accept": false
    },
    "were": 949,
    "went": true,
    "sun": {
      "worried": null,
      "lift": null,
      "hurry": 10.603214194393406
    },
    "event": 1849,
    "wooden": ["jar", "step", "across", "yet"],
    "coffee": {
      "finish": null,
      "particular": "massage thus flame"
    }
  }
  `

const jsonObj = JSON.parse(jsonString);
console.log(jsonObj);